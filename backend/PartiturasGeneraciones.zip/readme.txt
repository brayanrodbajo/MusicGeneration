Brayan Mauricio Rodr�guez Rivera - C�digo: 201225796
La actual carpeta contiene los archivos de las partituras de piano y bajo respectivamente, en formato PDF, 
correspondientes a las tres canciones generadas autom�ticamente descritas en el Cap�tulo 5 del documento final.